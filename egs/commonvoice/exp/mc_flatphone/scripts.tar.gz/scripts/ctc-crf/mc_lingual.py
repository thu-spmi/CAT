"""
Copyright 2021 Tsinghua University
Apache 2.0.

Author: Chengrui Zhu  2021
        Wenjie Peng   2021

This script implements multi/cross-lingual related functions originally written by Chengrui Zhu,
which is latter refactored by Wenjie Peng.
"""

import json
import numpy as np
from collections import OrderedDict
import torch
import torch.nn as nn


def load_token_idx(fin):
    idx = OrderedDict()
    with open(fin, "r") as fp:
        for line in fp.readlines():
            line = line.strip().split()
            k, v = line[0], int(line[1])
            if k == "#0":
                break
            idx.update({k:v})
    return idx


def load_src_idx(f1, f2):

    idx1 = load_token_idx(f1)
    idx2 = load_token_idx(f2)
    src_idx = []
    for i in range(len(idx2)):
        k = list(idx2.keys())[i]
        if k in idx1:
            v = idx1[k]
            src_idx.append(v)
    return src_idx


def load_des_idx(fin):
    idx = load_token_idx(fin)
    return list(idx.values())


def load_pv(fin):

    pv = np.load(fin)
    pv = torch.Tensor(pv)
    return pv


def load_mc_conf(conf):

    with open(conf, "r") as fp:
        config = json.load(fp)
    src_idx = load_src_idx(config["src_tokens"], config["des_tokens"])
    des_idx = load_des_idx(config["des_tokens"])
    
    pv = load_pv(config["P"])
    hdim = config["hdim"]
    odim = config["odim"]
    mode = config["mode"]

    return src_idx, des_idx, pv, hdim, odim, mode

def update_ckpt(ckpt, conf, loc, usg):

    src_idx, des_idx, pv, hdim, odim, mode = load_mc_conf(conf)
    ckpt = reset_network(ckpt, loc, mode, usg, pv, src_idx, des_idx)

    return ckpt


def reset_network(ckpt, loc, mode, usg, pv, src_idx, des_idx):
    """
    Reset neural network topology for multilingual finetune..
    Args   :
        ckpt    : saved checkpoint of trained model.
        loc     : device location.
        src_idx : index of the seen AM units in the last hidden layer of the pretrained model.
        des_idx : index of the seen AM units in the last hidden layer of the new model for finetune.
        P       : phonological vector matrix of the target language.
        hdim    : input dim of the last hidden layer.
        odim    : output dim of the last hidden layer.
        mode    : [train|eval]
    Returns:
    """

    # new transformation matrix before Softmax layer
    assert mode in ["flat_phone", "join_ap"]
    assert usg in ["finetune", "eval"]
    if mode == 'join_ap':
        # JoinAP finetune or eval
        P = nn.Parameter(pv, requires_grad = False)
        bias = torch.zeros(P.size()[0])
        if usg == "finetune":
            ckpt["model"]["module.infer.P.weight"] = P
            ckpt["model"]["module.infer.P.bias"] = bias
        else:
            ckpt["P.weight"] = P
            ckpt["P.bias"] = bias
    else:
        # Flat-phone finetune or eval
        new_linear = nn.Linear(hdim, odim)
        new_linear.weight.requires_grad = False
        new_linear.bias.requires_grad = False
        new_linear.to(device=loc)

        new_linear.weight[des_idx] = ckpt["model"]["module.infer.linear.weight"][src_idx]
        new_linear.bias[des_idx] = ckpt["model"]["module.infer.linear.bias"][src_idx]
        new_linear.weight.requires_grad = True
        new_linear.bias.requires_grad = True

        ckpt["model"]["module.infer.linear.weight"] = new_linear.weight
        ckpt["model"]["module.infer.linear.bias"] = new_linear.bias
        
        if len(src_idx) > 0:
            ckpt["scheduler"]["optimizer"]["state"][weight_idx]["exp_avg"] = ckpt["scheduler"]["optimizer"]["state"][weight_idx][src_idx]
            ckpt["scheduler"]["optimizer"]["state"][bias_idx]["exp_avg"] = ckpt["scheduler"]["optimizer"]["state"][bias_idx]["exp_avg"][src_idx]
        else:
            print(f"No seen phones in the target language, you'd better to check the conf files")
            exit(1)

    return ckpt

