#!/bin/bash

# Copyright 2021 Tsinghua University
# Author: Chengrui Zhu
# Apache 2.0.
# This script implements JoinAP multilingual training.

. ./cmd.sh
. ./path.sh

stage=7
stop_stage=100
H=`pwd`  #exp home
n=8      #parallel jobs#!/usr/bin/env bash

#datadir=/mnt/workspace/pengwenjie/espnet/egs/commonvoice/asr1/download/de_data

NODE=$1
if [ ! $NODE ]; then
    NODE=0
fi

datadir=/mnt/nas_workspace2/spmiData/MozillaCommonVoice/cv-corpus-5.1-2020-06-22/
g2ps=/mnt/workspace/pengwenjie/g2ps/models/ # path to g2p models, downloaded from https://github.com/uiuc-sst/g2ps
fr_lex_url='http://www.lexique.org/databases/Lexique383/Lexique383.tsv'
fr_pure_word=data/local/dict_tmp/fr_pure_word.txt
saved_dict=./saved_dict
dict_tmp=data/local/dict_tmp
mkdir -p $dict_tmp

if [ $NODE == 0 ]; then
    if [ $stage -le 1 ] && [ $stop_stage -ge 1 ]; then
        echo "Data Preparation and FST Construction"
        # Use the same datap prepatation script from Kaldi, create directory data/train, data/dev and data/test, 
        for lang in fr it es de;  do
            train_set=train_"$(echo "${lang}" | tr - _)"
            train_dev=dev_"$(echo "${lang}" | tr - _)"
            test_set=test_"$(echo "${lang}" | tr - _)"  
            for part in validated test dev; do
            # use underscore-separated names in data directories.
                if [ $lang = "fr" ]; then
                    local/data_prep.pl "${datadir}/$lang" ${part}_filt data/"$(echo "${part}_${lang}" | tr - _)"
                else
                    local/data_prep.pl "${datadir}/$lang" ${part} data/"$(echo "${part}_${lang}" | tr - _)"
                fi
                cat data/"$(echo "${part}_${lang}" | tr - _)"/text | sed 's/"//g' | sed 's/,//g' | sed 's/\.//g' | sed 's/\?//g' | sed 's/\!//g' | sed 's/…//g' | sed 's/;//g' | sed 's/  / /g' | sed 's/  / /g' | sed 's/ $//g' | sed "s/’/'/g" > data/"$(echo "${part}_${lang}" | tr - _)"/text_fil
                mv data/"$(echo "${part}_${lang}" | tr - _)"/text_fil data/"$(echo "${part}_${lang}" | tr - _)"/text
                if [ $lang = 'it' ] || [ $lang = 'fr' ]; then
                    tr A-Z a-z < data/${part}_${lang}/text > data/${part}_${lang}/text.tmp
                    mv data/${part}_${lang}/text.tmp data/${part}_${lang}/text
                fi
            done
            utils/copy_data_dir.sh data/"$(echo "validated_${lang}" | tr - _)" data/${train_set}
            utils/filter_scp.pl --exclude data/${train_dev}/wav.scp data/${train_set}/wav.scp > data/${train_set}/temp_wav.scp
            utils/filter_scp.pl --exclude data/${test_set}/wav.scp data/${train_set}/temp_wav.scp > data/${train_set}/wav.scp
            utils/fix_data_dir.sh data/${train_set}

            cat data/${train_set}/text | awk '{$1="";print $0}' | sed 's/ /\n/g' | sort -u > $dict_tmp/wordlist_${lang}
        done
        exit 0

#    phonetisaurus-apply --model $g2ps/french_8_4_2.fst --word_list $dict_tmp/wordlist_fr | sed 's/[1-9]//g' | sed 's/\ \ //g' > $dict_tmp/lexicon_fr
#    phonetisaurus-apply --model $g2ps/german_8_4_2.fst --word_list $dict_tmp/wordlist_de > $dict_tmp/lexicon_de
#    phonetisaurus-apply --model $g2ps/spanish_4_3_2.fst --word_list $dict_tmp/wordlist_es > $dict_tmp/lexicon_es
#    phonetisaurus-apply --model $g2ps/italian_8_2_3.fst --word_list $dict_tmp/wordlist_it > $dict_tmp/lexicon_it

        for part in train test dev; do
            mkdir -p data/${part}
            touch data/${part}/spk2utt
            touch data/${part}/text
            touch data/${part}/utt2spk
            touch data/${part}/wav.scp
            for lang in de fr es it; do
                cat data/${part}_${lang}/spk2utt >> data/${part}/spk2utt
                cat data/${part}_${lang}/text >> data/${part}/text
                cat data/${part}_${lang}/utt2spk >> data/${part}/utt2spk
                cat data/${part}_${lang}/wav.scp >> data/${part}/wav.scp
            done
            utils/fix_data_dir.sh data/${part}
        done
    fi
    
    if [ $stage -le 2 ] && [ $stop_stage -ge 2 ]; then
        
        mul_lexicon=$saved_dict/lexicon_mul.txt
        local/mozilla_prepare_phn_dict.sh $mul_lexicon || exit 1;
        ctc-crf/ctc_compile_dict_token.sh --dict-type "phn" \
        data/dict_phn data/local/lang_phn_tmp data/lang_phn 
    fi
    
    if [ $stage -le 3 ] && [ $stop_stage -ge 3 ]; then
        echo "FBank Feature Generation"
        #perturb the speaking speed to achieve data augmentation
        # utils/data/perturb_data_dir_speed_3way.sh data/train data/train_sp
        # utils/data/perturb_data_dir_speed_3way.sh data/dev data/dev_sp
        fbankdir=fbank
        for x in train dev test test_de test_fr test_es test_it; do
            steps/make_fbank.sh --cmd "$train_cmd" --nj 20 --fbank-config conf/vggblstm_fbank.conf data/$x exp/make_fbank/$x $fbankdir || exit 1;
            utils/fix_data_dir.sh data/$x || exit;  #filter and sort the data files
            steps/compute_cmvn_stats.sh data/$x exp/make_fbank/$x $fbankdir || exit 1;  #achieve cmvn normalization
        done
    fi

    data_tr=data/train
    data_cv=data/dev
    
    if [ $stage -le 4 ] && [ $stop_stage -ge 4 ]; then
    #convert word sequences to label sequences according to lexicon_numbers.txt and text files in data/lang_phn
    #the result will be placed in $data_tr/ and $data_cv/
        python3 ctc-crf/prep_ctc_trans.py data/lang_phn/lexicon_numbers.txt $data_tr/text "<UNK>" > $data_tr/text_number
        python3 ctc-crf/prep_ctc_trans.py data/lang_phn/lexicon_numbers.txt $data_cv/text "<UNK>" > $data_cv/text_number
        echo "convert text_number finished"
    
    fi
    
    
    if [ $stage -le 5 ] && [ $stop_stage -ge 5 ]; then
        feats_tr="ark,s,cs:apply-cmvn --norm-vars=true --utt2spk=ark:$data_tr/utt2spk scp:$data_tr/cmvn.scp scp:$data_tr/feats.scp ark:- \
    | add-deltas ark:- ark:- | subsample-feats --n=3 ark:- ark:- |"
    # echo "$feats_tr"
        feats_cv="ark,s,cs:apply-cmvn --norm-vars=true --utt2spk=ark:$data_cv/utt2spk scp:$data_cv/cmvn.scp scp:$data_cv/feats.scp ark:- \
    | add-deltas ark:- ark:- | subsample-feats --n=3 ark:- ark:- |"
        ark_dir=data/all_ark
        mkdir -p $ark_dir
        #copy feature files, generate scp and ark files to save features.
        copy-feats "$feats_tr" "ark,scp:$ark_dir/tr.ark,$ark_dir/tr.scp" || exit 1
        copy-feats "$feats_cv" "ark,scp:$ark_dir/cv.ark,$ark_dir/cv.scp" || exit 1
        echo "copy -feats finished"
    fi

    if [ $stage -le 6 ] && [ $stop_stage -ge 6 ]; then
  
        mkdir -p data/den_meta
        cat $data_tr/text_number | sort -k 2 | uniq -f 1 > $data_tr/unique_text_number
        chain-est-phone-lm ark:$data_tr/unique_text_number data/den_meta/phone_lm.fst
        python3 ctc-crf/ctc_token_fst_corrected.py den data/lang_phn/tokens.txt | fstcompile | fstarcsort --sort_type=olabel > data/den_meta/T_den.fst
        fstcompose data/den_meta/T_den.fst data/den_meta/phone_lm.fst > data/den_meta/den_lm.fst
        echo "prepare denominator finished"
        path_weight $data_tr/text_number data/den_meta/phone_lm.fst > $data_tr/weight
        path_weight $data_cv/text_number data/den_meta/phone_lm.fst > $data_cv/weight

        ark_dir=data/all_ark

        mkdir -p data/pickle
        python3 ctc-crf/convert_to.py -f=pickle --describe='L//1' --filer=-1 \
            $ark_dir/cv.scp $data_cv/text_number $data_cv/weight data/pickle/cv.pickle || exit 1
        python3 ctc-crf/convert_to.py -f=pickle --describe='L//1' --filer=-1 \
            $ark_dir/tr.scp $data_tr/text_number $data_tr/weight data/pickle/tr.pickle || exit 1
    fi

fi


PARENTDIR='.'
dir="exp/mc_linear/"
DATAPATH=$PARENTDIR/data/

output_unit=$(awk '{if ($1 == "#0")print $2 - 1 ;}' data/lang_phn/tokens.txt)
if [ $stage -le 7 ] && [ $stop_stage -ge 7 ]; then
    unset CUDA_VISIBLE_DEVICES
    
    if [[ $NODE == 0 && ! -f $dir/scripts.tar.gz ]]; then
        echo ""
        tar -zcf $dir/scripts.tar.gz $(readlink ctc-crf) $0
    elif [ $NODE == 0 ]; then
        echo ""
        echo "'$dir/scripts.tar.gz' already exists."
        echo "If you want to update it, please manually rm it then re-run this script."
    fi

  # uncomment the following line if you want to use specified GPUs
    CUDA_VISIBLE_DEVICES=0,1,2                      \
    python3 ctc-crf/train.py --seed=0               \
    	--workers=4				    \
        --world-size 1 --rank $NODE                 \
        --batch_size=128                            \
        --mc-conf=./conf/mc_conf.json               \
	--mc-train-pv=./multilingual_p.npy	    \
        --dir=$dir                                  \
        --config=$dir/config.json                   \
        --data=$DATAPATH                            \
        || exit 1
fi

exit 0

if [ $NODE -ne 0 ]; then
    exit 0
fi
exit 1;
nj=$n
if [ $stage -le 8 ] && [ $stop_stage -ge 8 ]; then
    for set in test_$lang; do
        ark_dir=$dir/logits/$set
        mkdir -p $ark_dir
        python3 ctc-crf/calculate_logits.py               \
            --mc-conf=./conf/mc_eval.conf                   \
            --resume=$dir/ckpt/infer.pt                     \
            --config=$dir/config.json                       \
            --nj=$nj --input_scp=data/all_ark/$set.scp      \
            --output_dir=$ark_dir                           \
            || exit 1
        
        ctc-crf/decode.sh  --stage 1 \
            --cmd "$decode_cmd" --nj $nj --acwt 1.0 \
            data/lang_phn_tgsmall data/$set data/test_data/test.scp $dir/decode_$set_tgsmall || exit 1
    done
fi
