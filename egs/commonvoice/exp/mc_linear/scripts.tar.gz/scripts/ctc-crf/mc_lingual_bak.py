"""
Copyright 2021 Tsinghua University
Apache 2.0.

Author: Chengrui Zhu  2021
        Wenjie Peng   2021

This script implements multi/cross-lingual related functions originally written by Chengrui Zhu,
which is latter refactored by Wenjie Peng.
"""

import json
import numpy as np
from collections import OrderedDict
import torch
import torch.nn as nn


def load_token_idx(fin):
    idx = OrderedDict()
    with open(fin, "r") as fp:
        for line in fp.readlines():
            line = line.strip().split()
            k, v = line[0], int(line[1])
            if k == "#0":
                break
            idx.update({k:v})
    return idx


def load_src_idx(f1, f2):

    idx1 = load_token_idx(f1)
    idx2 = load_token_idx(f2)
    src_idx = []
    for i in range(len(idx2)):
        k = list(idx2.keys())[i]
        if k in idx1:
            v = idx1[k]
            src_idx.append(v)
    return src_idx


def load_des_idx(fin):
    idx = load_token_idx(fin)
    return list(idx.values())


def load_pv(fin):

    P = np.load(fin)
    P = torch.Tensor(P)
    return P


def load_mc_conf(conf):

    with open(conf, "r") as fp:
        config = json.load(fp)
    src_idx = load_src_idx(config["src_tokens"], config["des_tokens"])
    des_idx = load_des_idx(config["des_tokens"])
    
    P = load_pv(config["P"])
    hdim = config["hdim"]
    odim = config["odim"]
    mode = config["mode"]
    model = config["model"]

    return src_idx, des_idx, P, hdim, odim, model

def update_ckpt(ckpt, args, loc, mode):

    src_idx, des_idx, P, hdim, odim, model = load_mc_conf(args.mc_conf)
    ckpt = reset_network(ckpt, loc, src_idx, des_idx, P, hdim, odim, mode, model)
    return ckpt


def reset_network(ckpt, loc, src_idx, des_idx, P, hdim, odim, mode="train", model="flat"):
    """
    Reset neural network topology for multilingual finetune..
    Args   :
        ckpt    : saved checkpoint of trained model.
        loc     : device location.
        src_idx : index of the seen AM units in the last hidden layer of the pretrained model.
        des_idx : index of the seen AM units in the last hidden layer of the new model for finetune.
        P       : phonological vector matrix of the target language.
        hdim    : input dim of the last hidden layer.
        odim    : output dim of the last hidden layer.
        mode    : [train|eval]
    Returns:
    """

    # new transformation matrix before Softmax layer
    new_A = nn.Linear(hdim, odim)
    new_A.weight.requires_grad = False
    new_A.bias.requires_gra = False
    new_A.to(device=loc)

    assert mode in ["train", "eval"]
    if mode == "train":
        # train mode
        # copy weight/bias of the last hidden layer belonging to the seen phone to
        # the new hidden layer for the target language.
        if model == 'linear':
            print(new_A.size())
            new_A.weight[des_idx] = ckpt["model"]["module.infer.A.weight"][src_idx]
            new_A.bias[des_idx] = ckpt["model"]["module.infer.A.bias"][src_idx]
            new_A.weight.requires_grad = True
            new_A.bias.requires_grad = True

            ckpt["model"]["module.infer.A.weight"] = new_A.weight
            ckpt["model"]["module.infer.A.bias"] = new_A.bias

            # update optimizer
            key2idx = {k:i for i,k in enumerate(ckpt["model"].keys())}
            weight_idx = key2idx["module.infer.A.weight"]
            bias_idx = key2idx["module.infer.A.bias"]

            ckpt["scheduler"]["optimizer"]["state"][weight_idx]["exp_avg"] = ckpt["scheduler"]["optimizer"]["state"][weight_idx]["exp_avg"][src_idx]
            ckpt["scheduler"]["optimizer"]["state"][bias_idx]["exp_avg"] = ckpt["scheduler"]["optimizer"]["state"][bias_idx]["exp_avg"][src_idx]

            ckpt["scheduler"]["optimizer"]["state"][weight_idx]["exp_avg_sq"] = ckpt["scheduler"]["optimizer"]["state"][weight_idx]["exp_avg_sq"][src_idx]
            ckpt["scheduler"]["optimizer"]["state"][bias_idx]["exp_avg_sq"] = ckpt["scheduler"]["optimizer"]["state"][bias_idx]["exp_avg_sq"][src_idx]

        elif model == 'nonlinear':
            pass
        else model == 'flat_phone'
        # update phonlogical vector matrix
        P = nn.Parameter(P, requires_grad = False)
        bias = torch.zeros(P.size()[0])
        ckpt["model"]["module.infer.P.weight"] = P
        ckpt["model"]["module.infer.P.bias"] = bias

    else:

        new_A = nn.Linear(hdim, odim)
        new_A.weight.requires_grad = False
        new_A.bias.requires_gra = False
        new_A.to(device=loc)
        # eval mode
        new_A.weight[des_idx] = ckpt["A.weight"][src_idx]
        new_A.bias[des_idx] = ckpt["A.bias"][src_idx]
        new_A.weight.requires_grad = True
        new_A.bias.requires_grad = True
        
        ckpt["A.weight"] = new_A.weight
        ckpt["A.bias"] = new_A.bias

        P = nn.Parameter(P, requires_grad = False)
        bias = torch.zeros(P.size()[0])

        ckpt["P.weight"] = P
        ckpt["P.bias"] = bias

    return ckpt

